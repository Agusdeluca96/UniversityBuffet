<?php

class UserRepository extends PDORepository {

    private static $instance;

    public static function getInstance() {

        if (!isset(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }


    public function loginUser($username, $password){

        $query = $this->queryList(
            "SELECT * FROM usuario WHERE usuario = ? AND clave = ?", array($username, $password));
        foreach ($query as $row){
            if(!($row['usuario'] == $username)){
                $result = null;
            }else{
                $result = new User($row['id'], $row['usuario'], $row['clave'], $row['nombre'], $row['apellido'], $row['mail'], $row['pais'], $row['fecha_registracion']);
            }
        }

        return $result;

    }

}
