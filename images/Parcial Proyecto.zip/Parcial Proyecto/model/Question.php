<?php

class Question {
    

    private $id;
    private $titulo;
    private $pregunta;
    private $nombre;
    private $fecha_creacion;
    
    public function __construct($id, $titulo, $pregunta, $nombre, $fecha_creacion) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->pregunta = $pregunta;
        $this->nombre = $nombre;
        $this->fecha_creacion = $fecha_creacion;
    }

    public function getId() {
        return $this->id;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function getPregunta() {
        return $this->pregunta;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getFechaCreacion() {
        return $this->fecha_creacion;
    }
}
