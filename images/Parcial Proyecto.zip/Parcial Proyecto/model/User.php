<?php

class User {
    

    private $id;
    private $username;
    private $passwd;
    private $nombre;
    private $apellido;
    private $mail;
    private $pais;
    private $fecha_registracion;
    
    public function __construct($id, $username, $passwd, $nombre, $apellido, $mail, $pais, $fecha_registracion) {
        $this->id = $id;
        $this->username = $username;
        $this->passwd = $passwd;
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->mail = $mail;
        $this->pais = $pais;
        $this->fecha_registracion = $fecha_registracion;
    }

    public function getId() {
        return $this->id;
    }

    public function getUsername() {
        return $this->username;
    }

    public function getPasswd() {
        return $this->passwd;
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getApellido() {
        return $this->apellido;
    }

    public function getMail() {
        return $this->mail;
    }

    public function getPais() {
        return $this->pais;
    }

    public function getFechaRegistracion() {
        return $this->fecha_registracion;
    }
}
