<?php

class QuestionRepository extends PDORepository {

    private static $instance;

    public static function getInstance() {

        if (!isset(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function addQuestion($title, $body, $id){

        $this->queryList(
            "INSERT INTO preguntas_usuario(titulo, pregunta, fecha_creacion, id_usuario) VALUES (?, ?, ?, ?)", array($title, $body, date('Y-m-d H:i:s'), $id));

    }


    public function listAll() {

        $answer = $this->queryList(
                "SELECT * FROM preguntas_usuario ORDER BY fecha_creacion", array());

        foreach ($answer as $row) {
            $query = $this->queryList(
                "SELECT * FROM usuario WHERE id = ?", array($row['id_usuario']));
            foreach ($query as $fila){
                $nombre = $fila['usuario'];
            }
            $question = new Question($row['id'], $row['titulo'], $row['pregunta'], $nombre, $row['fecha_creacion']);
            $questions[]=$question;
        }

        return $questions;
    }

}
