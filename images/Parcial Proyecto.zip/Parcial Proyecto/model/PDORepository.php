<?php

abstract class PDORepository {
    
    const USERNAME = "FCrhyU";
    const PASSWORD = "XbiL9b";
	const HOST ="localhost";
	const DB = "FCrhyU";
    
    
    private function getConnection(){
        $u=self::USERNAME;
        $p=self::PASSWORD;
        $db=self::DB;
        $host=self::HOST;
        $connection = new PDO("mysql:dbname=$db;host=$host", $u, $p);
        return $connection;
    }
    
    protected function queryList($sql, $args){  //LA UTILIZACION DE PREPARED STATEMENT EVITA LAS INYECCIONES SQL
        $connection = $this->getConnection();
        $stmt = $connection->prepare($sql);
        $stmt->execute($args);
        return $stmt;
    }
    
}
