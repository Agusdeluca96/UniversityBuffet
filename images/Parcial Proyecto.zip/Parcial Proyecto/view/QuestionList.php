<?php

class QuestionList extends TwigView {
    
    public function show($questions) {
        
        echo self::getTwig()->render('questionsList.html.twig', array('questions' => $questions));
        
        
    }
    
}

?>