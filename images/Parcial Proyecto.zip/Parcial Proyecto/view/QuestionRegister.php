<?php

class QuestionRegister extends TwigView {
    
    public function show() {
        
        echo self::getTwig()->render('questionRegister.html.twig');
        
        
    }
    
}

?>