<?php

session_start();
if(!isset($_SESSION)){
	$_SESSION['id']=null;	
}

ini_set('display_startup_errors',1);
ini_set('display_errors',1);
error_reporting(-1);

require_once('controller/Controller.php');
require_once('model/PDORepository.php');
require_once('model/UserRepository.php');
require_once('model/User.php');
require_once('model/QuestionRepository.php');
require_once('model/Question.php');
require_once('view/TwigView.php');
require_once('view/SimpleResourceList.php');
require_once('view/Home.php');
require_once('view/Login.php');
require_once('view/QuestionRegister.php');
require_once('view/QuestionList.php');

$permission = array('login', 'home', 'login_check');


if(isset($_GET['action'])){
	$method = $_GET['action'];
	if(!is_null($_SESSION['id'])){ //SI NO ESTA LOGUEADO SE LO ENVIA POR DEFECTO AL LOGIN CUANDO INTENTA ACCEDER A OTRO LUGAR DEL SITIO
		Controller::getInstance()->$method();	
	}else{
		if(in_array($method, $permission)){
			Controller::getInstance()->$method();	
		}else{
			Controller::getInstance()->login();
		}
		
	}
    
}else{
    Controller::getInstance()->home();
}

