-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 03-12-2016 a las 09:50:00
-- Versión del servidor: 10.0.28-MariaDB-0+deb8u1
-- Versión de PHP: 5.6.27-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `FCrhyU`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas_usuario`
--

CREATE TABLE IF NOT EXISTS `preguntas_usuario` (
`id` int(10) unsigned NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `pregunta` varchar(255) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `preguntas_usuario`
--

INSERT INTO `preguntas_usuario` (`id`, `titulo`, `pregunta`, `fecha_creacion`, `id_usuario`) VALUES
(1, 'Error Unexpected character # en plantilla de Symfony con Javascript y Ajax', 'Estoy intentando probar un formulario con Symfony con un código copiado de internet, pero cuando cargo la pagina me marca el siguiente error: Unexpected character "#" in NoxLogicDemoBundle', '2016-11-29 00:00:00', 2),
(2, 'Hacer que una página solo se acceda desde un enlace específico', 'Pues tengo un enlace desde un correo electrónico exclusivo y quiero que sólo se pueda acceder a través de éste a la página en cuestión (es una oferta sólo accseible desde ahí). Alguien sabe cómo?', '2016-12-01 00:00:00', 2),
(3, 'Python: modo server para comprobar registros en PLC', 'Me gustaría imprimir por pantalla el valor del registro 40001 ¿Alguien puede ayudarme? Además se cae constantemente y vuelve a conectar el server. ¿Porque?', '2016-12-01 00:00:00', 7),
(4, 'Modificar nodo en C', 'Tengo esta función para modificar un nodo, pero cuando la uso lo que hace es modificar el nodo que le pedí pero borra las demás. ¿Cómo puedo hacer para que modifique y no borre los otros nodos?.', '2016-11-26 00:00:00', 5),
(5, 'ingresar numeros de derecha a izquierda en un cuadro de entrada numerico', '¿como puedo hacer que en un cuadro de entrada de tipo numérico al escribir números aparezcan de derecha a izquierda asi como en las calculadoras de los celulares cuando empezamos a poner los numeros?', '2016-12-01 00:00:00', 3),
(6, '¿Como puedo proteger la privacidad de un dominio .mx?', 'Quiero proteger la información de contacto de un dominio .mx para los registros whois, existe alguna manera oficial de hacerlo o pueden compartir algunas tecnicas extra oficiales para lograr esto?', '2016-12-01 00:00:00', 7),
(7, 'GridView con imágenes en Storage de Firebase', 'Necesito crear un GridView con imágenes que están almacenadas en Firebase Storage, ¿alguien sabe cómo puedo acceder a todas las imágenes del Storage en Firebase? ', '2016-12-02 00:00:00', 5),
(8, 'sadaweq', 'nmnmnmn', '2016-12-03 09:08:42', 1),
(13, 'dale que va', 'hoy hay que ganar', '2016-12-03 09:13:59', 1),
(14, 'dale', 'barsa', '2016-12-03 09:17:28', 1),
(15, 'sdasdadsa', 'asdasdasda', '2016-12-03 09:20:32', 1),
(16, 'pregunta de prueba', 'vamos los pibes', '2016-12-03 09:27:11', 1),
(17, 'ultima', 'daledaledale', '2016-12-03 09:28:08', 1),
(18, 'asdasdas', 'dfgdfgd', '2016-12-03 09:44:59', 1),
(19, 'rrrrrrrrr', 'ttttttttttt', '2016-12-03 09:45:25', 1),
(20, 'rrrrrrrrr', 'ttttttttttt', '2016-12-03 09:45:45', 1),
(21, 'qqqqqqqqq', 'qqqqqqq', '2016-12-03 09:46:07', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
`id` int(10) unsigned NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `mail` varchar(45) NOT NULL,
  `pais` varchar(45) DEFAULT NULL,
  `fecha_registracion` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `usuario`, `clave`, `nombre`, `apellido`, `mail`, `pais`, `fecha_registracion`) VALUES
(1, 'administrador', '123456', 'Carlos Salvador', 'Bilardo', 'cbilardo@gmail.com', 'Argentina', '2016-05-25 00:00:00'),
(2, 'usuario', '123456', 'Pedro', 'Troglio', 'troglio@gmail.com', 'Argentina', '2016-06-12 00:00:00'),
(3, 'bruja', '123456', 'Juan Sebastián', 'Verón', 'veronjuanse@gmail.com', 'Argentina', '2016-09-01 00:00:00'),
(4, 'enzo', '123456', 'Enzo', 'Francescoli', 'soyderiver@hotmail.com', 'Uruguay', '2016-09-01 00:00:00'),
(5, 'diego', '123456', 'Diego Armando', 'Maradona', 'diego_a@gmail.com', 'Argentina', '2016-09-12 00:00:00'),
(6, 'kun', '123456', 'Sergio', 'Agüero', 'benjamin@gmail.com', 'Argentina', '2016-11-25 00:00:00'),
(7, 'diegom', '123456', 'Diego', 'Milito', 'diego_mil@yahoo.com.ar', 'Argentina', '2016-11-25 00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `preguntas_usuario`
--
ALTER TABLE `preguntas_usuario`
 ADD PRIMARY KEY (`id`), ADD KEY `FK_preguntas` (`id_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `preguntas_usuario`
--
ALTER TABLE `preguntas_usuario`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `preguntas_usuario`
--
ALTER TABLE `preguntas_usuario`
ADD CONSTRAINT `FK_proyecto` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
